package com.example.agent_rnd.domain.enums;

/**
 * DB: plans.plan_type
 */
public enum PlanType {
    FREE,
    PAID
}
