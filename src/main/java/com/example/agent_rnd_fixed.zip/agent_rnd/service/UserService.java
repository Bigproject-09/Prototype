package com.example.agent_rnd.service;

import com.example.agent_rnd.client.BusinessVerifyClient;
import com.example.agent_rnd.dto.AuthDtos;
import com.example.agent_rnd.domain.company.Company;
import com.example.agent_rnd.domain.enums.UserEntityType;
import com.example.agent_rnd.domain.enums.UserRole;
import com.example.agent_rnd.domain.plan.Plan;
import com.example.agent_rnd.domain.proposal.Proposal;
import com.example.agent_rnd.domain.user.User;
import com.example.agent_rnd.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class UserService {

    private final UserRepository userRepository;
    private final CompanyRepository companyRepository;
    private final CompanyTagRepository companyTagRepository;
    private final PlanRepository planRepository;

    private final BusinessVerifyClient businessVerifyClient;
    private final EmailAuthService emailAuthService;

    private final NoticeAttachmentRepository noticeAttachmentRepository;
    private final ProposalRepository proposalRepository;
    private final PresentationRepository presentationRepository;
    private final ScriptRepository scriptRepository;
    private final PaymentRepository paymentRepository;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Transactional
    public SignupResult companySignupAndCreateMaster(AuthDtos.CompanySignupRequest req) {

        String bno = normalizeDigits(req.businessRegNo());
        String startDt = normalizeDigits(req.openDate());
        String pnm = (req.ceoName() == null) ? "" : req.ceoName().trim();

        if (bno.length() != 10) throw new IllegalArgumentException("사업자등록번호는 숫자 10자리여야 합니다.");
        if (startDt.length() != 8) throw new IllegalArgumentException("개업일자는 YYYYMMDD 형식이어야 합니다.");
        if (pnm.isBlank()) throw new IllegalArgumentException("대표자명은 필수입니다.");

        String email = (req.email() == null) ? "" : req.email().trim().toLowerCase();
        if (email.isBlank()) throw new IllegalArgumentException("이메일은 필수입니다.");

        if (companyRepository.existsByBusinessRegNo(bno)) {
            throw new IllegalArgumentException("이미 등록된 사업자등록번호입니다.");
        }
        if (!emailAuthService.isVerified(email)) {
            throw new IllegalArgumentException("이메일 인증이 필요합니다.");
        }
        if (userRepository.existsByEmail(email)) {
            throw new IllegalArgumentException("이미 사용 중인 이메일입니다.");
        }

        if (req.password() == null || req.password().isBlank()) throw new IllegalArgumentException("비밀번호는 필수입니다.");
        if (!req.password().equals(req.passwordConfirm())) throw new IllegalArgumentException("비밀번호 확인이 일치하지 않습니다.");

        var verifyRes = businessVerifyClient.validate(bno, startDt, pnm);
        if (verifyRes == null || verifyRes.data() == null || verifyRes.data().isEmpty()) {
            throw new IllegalArgumentException("사업자 진위확인 응답이 비정상입니다.");
        }
        var item = verifyRes.data().get(0);
        if (!"01".equals(item.valid())) {
            throw new IllegalArgumentException("사업자 진위확인 실패: " + item.valid_msg());
        }

        // ✅ tax_type_cd 는 validate 응답의 status() 안에 있음
        String taxTypeCd = (item.status() == null) ? null : item.status().tax_type_cd();
        UserEntityType userEntityType = UserEntityType.fromTaxTypeCd(taxTypeCd);

        int resolvedPlanId = (req.planId() == null) ? 1 : req.planId();
        Plan plan = planRepository.findById(resolvedPlanId)
                .orElseThrow(() -> new IllegalArgumentException("플랜이 존재하지 않습니다."));

        LocalDateTime now = LocalDateTime.now();
        LocalDateTime end = now.plusYears(1);

        Company company = Company.create(req.companyName(), bno, now, end, userEntityType);
        companyRepository.save(company);

        String encoded = passwordEncoder.encode(req.password());
        User master = User.createMaster(company, plan, email, encoded);
        userRepository.save(master);

        return new SignupResult(company.getCompanyId(), master.getUserId());
    }

    @Transactional
    public void deleteCompanySignup(Long companyId) {
        Company company = companyRepository.findById(companyId)
                .orElseThrow(() -> new IllegalArgumentException("회사가 없습니다."));

        userRepository.findAll().stream()
                .filter(u -> Objects.equals(u.getCompany().getCompanyId(), companyId) && u.getRole() == UserRole.MEMBER)
                .forEach(u -> hardDeleteUser(u.getUserId()));

        userRepository.findAll().stream()
                .filter(u -> Objects.equals(u.getCompany().getCompanyId(), companyId) && u.getRole() == UserRole.ADMIN)
                .forEach(u -> hardDeleteUser(u.getUserId()));

        userRepository.findAll().stream()
                .filter(u -> Objects.equals(u.getCompany().getCompanyId(), companyId) && u.getRole() == UserRole.MASTER)
                .forEach(u -> hardDeleteUser(u.getUserId()));

        companyTagRepository.deleteByCompany_CompanyId(companyId);
        companyRepository.delete(company);
    }

    @Transactional
    protected void hardDeleteUser(Long userId) {
        userRepository.findByParent_UserId(userId)
                .forEach(child -> hardDeleteUser(child.getUserId()));

        List<Proposal> proposals = proposalRepository.findByUser_UserId(userId);
        for (Proposal p : proposals) {
            // ✅ Proposal 엔티티 id getter 맞추기 (대부분 getProposalId())
            Long proposalId = p.getProposalId();

            var presentations = presentationRepository.findByProposal_Id(proposalId);
            for (var pres : presentations) {
                // ✅ Presentation 엔티티 id getter 맞추기 (대부분 getPresentationId())
                scriptRepository.deleteByPresentation_Id(pres.getPresentationId());
            }

            presentationRepository.deleteByProposal_Id(proposalId);
        }

        noticeAttachmentRepository.deleteByUser_UserId(userId);
        proposalRepository.deleteByUser_UserId(userId);
        paymentRepository.deleteByUser_UserId(userId);

        userRepository.deleteById(userId);
    }

    private String normalizeDigits(String s) {
        return (s == null) ? "" : s.replaceAll("[^0-9]", "");
    }

    public record SignupResult(Long companyId, Long adminUserId) {}
}
